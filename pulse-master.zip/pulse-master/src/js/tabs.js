(function ($) {
  $(function () {
    // переключение табов
    $('ul.catalog__tabs').on(
      'click',
      'li:not(.catalog__tab_active)',
      // изменение (переключение) карточек внутри табов при перекл табов
      function () {
        $(this)
          .addClass('catalog__tab_active')
          .siblings()
          .removeClass('catalog__tab_active')
          .closest('div.container')
          .find('div.catalog__content')
          .removeClass('catalog__content_active')
          .eq($(this).index())
          .addClass('catalog__content_active');
      }
    );

    // при клике ПОДРОБНЕЕ открывается 2я скрытая сторона карточки
    // $('.catalog-item__link').each(function (i) {
    //   $(this).on('click', function (e) {
    //     e.preventDefault();
    //     $('.catalog-item__content')
    //       .eq(i)
    //       .toggleClass('catalog-item__content_active');
    //     $('.catalog-item__list').eq(i).toggleClass('catalog-item__list_active');
    //   });
    // });

    // при клике НАЗАД возвращается на 1 сторону карточка
    // $('.catalog-item__back').each(function (i) {
    //   $(this).on('click', function (e) {
    //     e.preventDefault();
    //     $('.catalog-item__content')
    //       .eq(i)
    //       .toggleClass('catalog-item__content_active');
    //     $('.catalog-item__list').eq(i).toggleClass('catalog-item__list_active');
    //   });
    // });

		// более оптимизированный вариант 2х функций выше
    function toggleSlide(item) {
      $(item).each(function (i) {
        $(this).on('click', function (e) {
          e.preventDefault();
          $('.catalog-item__content')
            .eq(i)
            .toggleClass('catalog-item__content_active');
          $('.catalog-item__list')
            .eq(i)
            .toggleClass('catalog-item__list_active');
        });
      });
    }

    toggleSlide('.catalog-item__link');
		toggleSlide('.catalog-item__back');
		
	
  });
})(jQuery);

// $(document).ready(function () {
//   $('ul.catalog__tabs').on(
//     'click',
//     'li:not(.catalog__tab_active)',
//     function () {
//       $(this)
//         .addClass('catalog__tab_active')
//         .siblings()
//         .removeClass('catalog__tab_active')
//         .closest('div.container')
//         .find('div.catalog__content')
//         .removeClass('catalog__content_active')
//         .eq($(this).index())
//         .addClass('catalog__content_active');
//     }
//   );
// });
