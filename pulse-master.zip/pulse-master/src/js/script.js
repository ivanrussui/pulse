// $(document).ready(function () {
//   $('.carousel__inner').slick({
// 		speed: 1000,
// 		// dots: true,
// 		adaptiveHeight: true,
// 		autoplay: true,
// 		autoplaySpeed: 2000,
// 		prevArrow: '<button type="button" class="slick-prev"><img src="icons/left.svg"></button>',
// 		nextArrow: '<button type="button" class="slick-next"><img src="icons/right.svg"></button>',
// 		responsive: [
// 			{
// 				breakpoint: 992,
// 				settings: {
// 					dots: true,
// 					arrows: false,
// 				}
//       }
// 		]
//   });
// });

const slider = tns({
  container: '.carousel__inner',
  items: 1,
  slideBy: 'page',
	controls: false,
	autoplay: 1000,
	autoplayHoverPause: true,
	autoplayButtonOutput: false,
  navPosition: 'bottom',
	speed: 600,
  responsive: {
		320: {
			nav: true,
		},
		768: {
			nav: false,
		},
  },
});

document.querySelector('.prev').addEventListener('click', function () {
  slider.goTo('prev');
});

document.querySelector('.next').addEventListener('click', function () {
  slider.goTo('next');
});
